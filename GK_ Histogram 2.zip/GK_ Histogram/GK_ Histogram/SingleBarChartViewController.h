//
//  SingleBarChartViewController.h
//  ZFChartView
//
//  Created by apple on 16/3/23.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZFChart.h"

@interface SingleBarChartViewController : UIViewController

@property (nonatomic, strong) NSArray *nameArr;
@property (nonatomic, strong) NSArray *dataArr;
@property (nonatomic, strong) NSArray *colorArr;
@property (nonatomic, strong) ZFBarChart * barChart;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat times;
@property (nonatomic, assign) CGFloat massage;

@end
