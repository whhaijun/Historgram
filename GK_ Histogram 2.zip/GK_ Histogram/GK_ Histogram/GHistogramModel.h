//
//  GHistogramModel.h
//  GK_ Histogram
//
//  Created by  北斗国科 on 16/12/6.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GHistogramModel : NSObject

//G03  42  25_  G05  43  23_  G07  49  41_  G09  52  44_  G10  47  34_  G16  44  26_  G19  47  35_  G23  51  38_  G27  47  33_  G28  42  22_  G30  48  36_  C01  48  46_  C02  38  34_  C03  46  40_  C04  48  45_  C06  46  45_  C07  47  44_  C09  47  46_  C10  41  40_  C14  50  48

@property (nonatomic, copy) NSString *name; // 卫星名称
@property (nonatomic, assign) NSString *SNR_1; // SNR1
@property (nonatomic, assign) NSString *SNR_2; // SNR2

@end
