//
//  SingleBarChartViewController.m
//  ZFChartView
//
//  Created by apple on 16/3/23.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "SingleBarChartViewController.h"

@interface SingleBarChartViewController ()<ZFGenericChartDataSource, ZFBarChartDelegate>



@end

@implementation SingleBarChartViewController

- (void)setUp{
    if ([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft || [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight){
        //首次进入控制器为横屏时
        _height = SCREEN_HEIGHT - NAVIGATIONBAR_HEIGHT * 0.5;
        
    }else{
        //首次进入控制器为竖屏时
        _height = SCREEN_HEIGHT - NAVIGATIONBAR_HEIGHT;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self setUp];
    _dataArr = [NSMutableArray new];
    _nameArr = [NSArray new];
    
    self.barChart = [[ZFBarChart alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, _height)];
    self.barChart.dataSource = self;
    self.barChart.delegate = self;
    self.barChart.topicLabel.text = @"信噪比图";
    self.barChart.unit = @"SNR(dB)";
    self.barChart.isAnimated = NO;
    self.barChart.isResetAxisLineMaxValue = YES;
    self.barChart.isShowSeparate = YES;
    self.barChart.isShowAxisArrows = NO;
    
    [self.view addSubview:self.barChart];
    [self.barChart strokePath];
    
    self.barChart.tag = 100;
}

#pragma mark - ZFGenericChartDataSource

- (NSArray *)valueArrayInGenericChart:(ZFGenericChart *)chart{

    return _dataArr;
}

- (NSArray *)nameArrayInGenericChart:(ZFGenericChart *)chart{
    return _nameArr;
}

- (NSArray *)colorArrayInGenericChart:(ZFGenericChart *)chart{
    NSMutableArray *mArr = [NSMutableArray array];
    for (NSString *str in _dataArr) {
        UIColor *color;
        if ([str intValue] > 40) {
            color = [UIColor greenColor];
            [mArr addObject:color];
        } else if ([str intValue] > 30) {
            color = [UIColor yellowColor];
            [mArr addObject:color];
        } else {
            color = [UIColor blueColor];
            [mArr addObject:color];
        }
    }
    return _colorArr = [NSArray arrayWithArray:mArr];
}

- (CGFloat)axisLineMaxValueInGenericChart:(ZFGenericChart *)chart{
    return _times;
}

- (NSUInteger)axisLineSectionCountInGenericChart:(ZFGenericChart *)chart{
    return _massage;
}

- (void)setDataArr:(NSArray *)dataArr {
    _dataArr = dataArr;

    [self.barChart strokePath];
}

- (void)setNameArr:(NSArray *)nameArr {
    _nameArr = nameArr;
}

- (void)setTimes:(CGFloat)times {
    _times = times;
}

- (void)setMassage:(CGFloat)massage {
    _massage = massage;
}

#pragma mark - ZFBarChartDelegate

- (CGFloat)barWidthInBarChart:(ZFBarChart *)barChart{
    return 20.f;
}

//- (void)barChart:(ZFBarChart *)barChart didSelectPopoverLabelAtGroupIndex:(NSInteger)groupIndex labelIndex:(NSInteger)labelIndex popoverLabel:(ZFPopoverLabel *)popoverLabel{
//    NSLog(@"第%ld组========第%ld个",(long)groupIndex,(long)labelIndex);
//}

//#pragma mark - 横竖屏适配(若需要同时横屏,竖屏适配，则添加以下代码，反之不需添加)
//
///**
// *  PS：size为控制器self.view的size，若图表不是直接添加self.view上，则修改以下的frame值
// */
//- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id <UIViewControllerTransitionCoordinator>)coordinator{
//    
//    if ([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft || [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight){
//        self.barChart.frame = CGRectMake(0, 0, size.width, size.height - NAVIGATIONBAR_HEIGHT * 0.5);
//    }else{
//        self.barChart.frame = CGRectMake(0, 0, size.width, size.height + NAVIGATIONBAR_HEIGHT * 0.5);
//    }
//    
//    [self.barChart strokePath];
//}

@end
