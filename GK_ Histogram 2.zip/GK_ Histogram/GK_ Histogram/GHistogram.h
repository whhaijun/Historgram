//
//  GHistogram.h
//  GK_ Histogram
//
//  Created by  北斗国科 on 16/12/6.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SingleBarChartViewController.h" // VC
@interface GHistogram : UIView

@property (nonatomic, strong) NSMutableArray *dataArr;
@property (nonatomic, strong) NSArray *nameArr;
@property (nonatomic, strong) SingleBarChartViewController *singleBarChartVC;

@end
