//
//  ViewController.m
//  GK_ Histogram
//
//  Created by  北斗国科 on 16/12/6.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import "ViewController.h"

#import "SingleBarChartViewController.h" // VC

#import "GHistogram.h" // view

#import "GHistogramModel.h" // model

@interface ViewController ()

@property (nonatomic, strong) GHistogram *histogram;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _dataArr = [NSMutableArray array];
    
//    55555;UNX3;  G03  42  25_  G05  43  23_  G07  49  41_  G09  52  44_  G10  47  34_  G16  44  26_  G19  47  35_  G23  51  38_  G27  47  33_  G28  42  22_  G30  48  36_  C01  48  46_  C02  38  34_  C03  46  40_  C04  48  45_  C06  46  45_  C07  47  44_  C09  47  46_  C10  41  40_  C14  50  48_;SNR END
    
    NSString *str = @"55555;UNX3;  G03  42  25_  G05  43  23_  G07  49  41_  G09  52  44_  G10  47  34_  G16  44  26_  G19  47  35_  G23  51  38_  G27  47  33_  G28  42  22_  G30  48  36_  C01  48  46_  C02  38  34_  C03  46  40_  C04  48  45_  C06  46  45_  C07  47  44_  C09  47  46_  C10  41  40_  C14  50  48_;SNR END  65536;DC11; G01   51.7   12.0_ G02  250.5   13.3_ G03   56.2   38.9_ G06  268.1   48.4_ G10  190.0   28.2_ G17  354.2   58.8_ G23  103.7    7.0_ G28  171.0   62.8_ C06  164.1   42.2_ C09  184.4   21.2_ C14  180.8   27.8_;sky end\r\n";
    
    NSRange start = [str rangeOfString:@"55555;"];
    NSRange end = [str rangeOfString:@"_;SNR END"];
    NSString *sub = [str substringWithRange:NSMakeRange(start.location, end.location-start.location)];

    NSString *strData = [[sub componentsSeparatedByString:@";  "] lastObject];
    NSArray *dataArr = [strData componentsSeparatedByString:@"_  "];
    NSLog(@"dataArr==%@",dataArr);
    
    for (int i = 0; i <dataArr.count; i++) {
        GHistogramModel *model = [GHistogramModel new];
        NSArray *arr = [dataArr[i] componentsSeparatedByString:@"  "];
        model.name = arr[0];
        model.SNR_1 = [NSString stringWithFormat:@"%@",arr[1]];
        model.SNR_2 = [NSString stringWithFormat:@"%@",arr[2]];
        [_dataArr addObject:model];
    }
    
    CGFloat width = (SWidth-40)/8.0;
    
    _histogram = [[GHistogram alloc]initWithFrame:CGRectMake(0, 20, SWidth, SHeight-(SWidth-2*width)-64)];
    [self.view addSubview:_histogram];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:@"获取数据" forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor grayColor];
    btn.frame = CGRectMake(20, SHeight-(SWidth-2*width)-64+80, SWidth-40, 50);
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}

- (void)btnClick:(UIButton *)btn {
    NSMutableArray *mArrName = [NSMutableArray array];
    NSMutableArray *mArrSNR = [NSMutableArray array];
    for (GHistogramModel *model in _dataArr) {
        [mArrName addObject:model.name];
        [mArrSNR addObject:model.SNR_1];
    }
    
    
    _histogram.nameArr = [NSArray arrayWithArray:mArrName];
    _histogram.dataArr = mArrSNR;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
