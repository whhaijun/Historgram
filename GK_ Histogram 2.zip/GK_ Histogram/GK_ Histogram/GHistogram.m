//
//  GHistogram.m
//  GK_ Histogram
//
//  Created by  北斗国科 on 16/12/6.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#import "GHistogram.h"



@implementation GHistogram

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        [self configView];
    }
    return self;
}

- (void)configView {
    CGFloat width = (SWidth-40)/8.0;
    _singleBarChartVC = [[SingleBarChartViewController alloc]init];
    _singleBarChartVC.height = SHeight-(SWidth-2*width)-64-40;
    _singleBarChartVC.times = 60;
    _singleBarChartVC.massage = 6;
    [self addSubview:_singleBarChartVC.view];
    
    CGRect blueRect = CGRectMake(50, CGRectGetHeight(self.frame)-40, 60, 10);
    CALayer *blueLayer = [self threeColorLayerRect:blueRect color:[UIColor blueColor]];
    [self.layer addSublayer:blueLayer];
    
    CGRect Rect0 = CGRectMake(50, CGRectGetHeight(self.frame)-40+10, 60, 10);
    CATextLayer *layer0 = [self textLayerRect:Rect0];
    layer0.string = @"0";
    [self.layer addSublayer:layer0];
    
    
    CGRect yellowRect = CGRectMake(50+60, CGRectGetHeight(self.frame)-40, 60, 10);
    CALayer *yellowLayer = [self threeColorLayerRect:yellowRect color:[UIColor yellowColor]];
    [self.layer addSublayer:yellowLayer];
    
    CGRect Rect31 = CGRectMake(50+60, CGRectGetHeight(self.frame)-40+10, 60, 10);
    CATextLayer *layer31 = [self textLayerRect:Rect31];
    layer31.string = @"31";
    [self.layer addSublayer:layer31];
    
    
    CGRect greenRect = CGRectMake(50+60+60, CGRectGetHeight(self.frame)-40, 60, 10);
    CALayer *greenLayer = [self threeColorLayerRect:greenRect color:[UIColor greenColor]];
    [self.layer addSublayer:greenLayer];
    
    CGRect Rect41 = CGRectMake(50+60+60, CGRectGetHeight(self.frame)-40+10, 60, 10);
    CATextLayer *layer41 = [self textLayerRect:Rect41];
    layer41.string = @"41";
    [self.layer addSublayer:layer41];
    
}

- (void)setNameArr:(NSArray *)nameArr {
    _nameArr = nameArr;
//    _singleBarChartVC.nameArr = _nameArr;
//    _singleBarChartVC.dataArr = _dataArr;
}

- (void)setDataArr:(NSMutableArray *)dataArr {
    _dataArr = dataArr;
    _singleBarChartVC.nameArr = _nameArr;
    _singleBarChartVC.dataArr = _dataArr;
}

- (CATextLayer *)textLayerRect:(CGRect)rect {
    CATextLayer *textLayer = [CATextLayer layer];
    textLayer.frame = rect;
    
    UIFont *font = [UIFont systemFontOfSize:10];
    CFStringRef fontName = (__bridge CFStringRef)(font.fontName);
    CGFontRef fontRef = CGFontCreateWithFontName(fontName);
    textLayer.font = fontRef;
    textLayer.fontSize = font.pointSize;
    textLayer.contentsScale = [UIScreen mainScreen].scale;
    CGFontRelease(fontRef);
    textLayer.alignmentMode = kCAAlignmentLeft;
    textLayer.foregroundColor = [UIColor blackColor].CGColor;
    return textLayer;
}

- (CALayer *)threeColorLayerRect:(CGRect)rect color:(UIColor *)color {
    CALayer *layer = [CALayer layer];
    layer.frame = rect;
    layer.backgroundColor = color.CGColor;
    return layer;
}
@end
