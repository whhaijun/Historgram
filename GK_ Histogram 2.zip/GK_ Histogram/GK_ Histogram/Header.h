//
//  Header.h
//  GK_ Histogram
//
//  Created by  北斗国科 on 16/12/6.
//  Copyright © 2016年  北斗国科. All rights reserved.
//

#ifndef Header_h
#define Header_h

//获取当前屏幕的高度
#define SHeight [UIScreen mainScreen].bounds.size.height

//获取当前屏幕的宽度
#define SWidth  [UIScreen mainScreen].bounds.size.width

#endif /* Header_h */
